package com.tr;

//An event class which contains the long word that was found
public class WordEvent {

 private String word;

 public WordEvent(String word) {
     this.word = word;
 }

 public String getWord() {
     return word;
 }
}