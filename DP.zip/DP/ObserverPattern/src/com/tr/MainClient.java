package com.tr;



	import java.util.ArrayList;
	import java.util.List;

	public class MainClient {

	    public static void main(String[] args) {

	        // create a list of words to be filled when long words were found
	        List<String> longWords = new ArrayList<>();

	        // create the PhraseProcessor class
	        PhraseProcessor processor = new PhraseProcessor();

	        // register an observer and specify what it should do when it receives events,
	        // namely to append long words in the longwords list
	        processor.addObserver(event -> longWords.add(event.getWord()));

	        // call the process method 
	        processor.process("Lorem ipsum dolor sit amet, consectetuer adipiscing elit");

	        // show the list of long words after the processing is done
	        System.out.println(String.join(", ", longWords));
	        // consectetuer, adipiscing
	    }
	}
