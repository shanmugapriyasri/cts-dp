package com.tr;

public interface Color {

	public void applyColor();
}
