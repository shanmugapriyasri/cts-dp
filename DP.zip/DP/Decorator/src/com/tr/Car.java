package com.tr;

public interface Car {

	public void assemble();
}