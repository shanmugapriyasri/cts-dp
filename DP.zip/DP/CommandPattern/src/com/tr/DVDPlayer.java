package com.tr;

public class DVDPlayer extends Receiver{
    
    public String toString(){
        return this.getClass().getSimpleName();
    }
}