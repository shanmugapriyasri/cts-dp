package com.tr;

import java.util.ArrayList;

public class Receiver {
    public void switchOn(){
        System.out.println("Switch on from:"+this.getClass().getSimpleName());
     
    }
    
   
}
