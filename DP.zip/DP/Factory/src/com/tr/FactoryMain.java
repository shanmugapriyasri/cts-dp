package com.tr;

//Factory client code
public class FactoryMain {
    public static void main(String args[]) {
           String country = "india";
           Currency rupee = CurrencyFactory.createCurrency(country);
           System.out.println(rupee.getSymbol());
    }
}

