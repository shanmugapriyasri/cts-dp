package com.tr;

public interface Menu
{
    public void showMenu();
}