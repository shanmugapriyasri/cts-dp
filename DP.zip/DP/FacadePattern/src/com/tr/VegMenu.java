package com.tr;

public class VegMenu implements Menu
{
 
    @Override
    public void showMenu()
    {
        System.out.println("Idly");
        System.out.println("Dosa");
        System.out.println("Vada");
    }
     
}