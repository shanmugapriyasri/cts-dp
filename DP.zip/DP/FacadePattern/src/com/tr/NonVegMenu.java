package com.tr;
public class NonVegMenu implements Menu
{
 
    @Override
    public void showMenu()
    {
        System.out.println("Chicken Biriyani");
        System.out.println("Tandoori");
    }
     
}