package com.tr;

import java.util.Objects;

public final class EagerInitializedSingleton {

    private static final EagerInitializedSingleton INSTANCE = new EagerInitializedSingleton();

    private EagerInitializedSingleton(){
        if(Objects.nonNull(INSTANCE)){
            throw new RuntimeException("This class can only be access through getInstance()");
        }
    }

    public synchronized static EagerInitializedSingleton getInstance(){
        return INSTANCE;
    }
}


